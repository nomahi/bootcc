bootcc <- function(model, cases, subcohort, B=2000){

	cases$d <- 1
	subcohort$d <- 0

	cc <- rbind(cases,subcohort)

	g1 <- glm(model,data=cc,family=binomial(link="logit"))

	Rb <- NULL

	noncases <- subcohort[subcohort$y==0,]

	m1 <- dim(cases)[1]
	m3 <- dim(noncases)[1]

	m2 <- dim(subcohort)[1] - m3

	q10 <- as.numeric(round(quantile(1:B,.1*1:10)))
	count <- 10

	for(q in 1:B){

		s1 <- sample(1:m1,m1,replace=TRUE)
		s3 <- sample(1:m3,m3,replace=TRUE)

		bsc1 <- cases[s1,]
		bsc3 <- noncases[s3,]
	
		s2 <- sample(1:m1,m2)
 
		bsc2 <- bsc1[s2,]
 
		bsc2$d <- 0

		bcc <- rbind(bsc1,bsc2,bsc3)

		bg1 <- glm(d ~ z + x1 + x2 ,data=bcc,family=binomial(link="logit"))

		bcoef1 <- summary(bg1)$coefficients[,1]

		Rb <- rbind(Rb,bcoef1)

		if(sum(q==q10)>0){
			print(paste0("The ",count," percents of the bootstrap is completed."))
			count <- count + 10
		}
	
	}

	se3 <- apply(Rb,2,sd)

	coef1 <- summary(g1)$coefficients[,1]

	cl <- coef1 - qnorm(.975)*se3
	cu <- coef1 + qnorm(.975)*se3

	p.value <- 2*pnorm(-abs(coef1/se3))

	R1 <- data.frame(coef1,se3,cl,cu,p.value)

	colnames(R1) <- c("coef","SE","95%CL","95%CU","P-value")
	
	return(R1)
	
}



# cases <- exdata$cases
# subcohort <- exdata$subcohort
# bootcc(d ~ z + x1 + x2, cases=cases, subcohort=subcohort, B=2000)









